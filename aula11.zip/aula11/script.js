var var1 = 10;
let let1 = 5;
const const1 = "15";
var1 += let1;
//var1 = var1.toString();
//const1 = Number(const1);

document.getElementById('js').innerText ="Olá mundo \n";
document.getElementById('js').innerText += "Var = " + var1 + "let=" + let1 + "const =" + const1 +"\n";
document.getElementById('js').innerText += "<hr> tipos Var = " + typeof(var1) + "tipo let=" + typeof(let1)  + "tipo const =" + typeof(const1)  +"\n";

const js = document.getElementById('js');
js.innerHTML += "<hr>";


//operadores Relacionais
js.innerHTML +="var1 com const1" +
"<br> var1 == const1 = " + (var1 == const1)+
"<br> var1 === const1 = " + (var1 === const1)+
"<br> var1 != const1 = " + (var1 != const1)+
"<br> var1 < const1 = " + (var1 < const1)+
"<br> var1 > const1 = " + (var1 > const1)+
"<br> var1 <= const1 = " + (var1 <= const1)+
"<br> var1 >= const1 = " + (var1 >= const1);


js.innerHTML += "<hr>";

//operadores Logicos
js.innerHTML += 
"<br> var1 == const1 E var1 == let1 =" + (var1 == const1 && var1 == let1) +
"<br> var1 == const1 E var1 OU let1 =" + (var1 == const1 || var1 == let1) ;


//estruturas de decisao

js.innerHTML += "<hr>";
if(var1++ == const1){
    js.innerHTML += "<h1> é igual </h1>";
}else{
    js.innerHTML += "<h1> <b> Nao </b> é igual </h1>";
}
js.innerHTML += (var1 == const1)? "<h1> é igual </h1>": "<h1> <b> Nao </b> é igual </h1>";


const semana = ["segunda", "terça", "quarta","quinta","sexta"];
switch(semana[0]){
    case "segunda":
        js.innerHTML += "<h3>Segunda</h3>"
        break;
    case "terça":
        js.innerHTML += "<h3>terça</h3>"
        break;
    case "quarta":
        js.innerHTML += "<h3>quarta</h3>"
        break;
    case "quinta":
        js.innerHTML += "<h3>quinta</h3>"
        break;

    case "sexta":
        js.innerHTML += "<h3>sexta</h3>"
        break;
}